//
//  Person.cpp
//  Donavin_CS223_PA3
//
//  Created by Kelsey Donavin on 9/26/18.
//  Copyright © 2018 Kelsey Donavin. All rights reserved.
//

#include "Person.hpp"

Person::Person()
{
    
}

Person::~Person()
{
    
}

void Person::setPosition(int newPosition)
{
    position = newPosition;
}

int Person::getPosition() const
{
    return position;
}

void Person::print()
{
    
}
