//
//  VectorMyJosephus.cpp
//  Donavin_CS223_PA3
//
//  Created by Kelsey Donavin on 9/26/18.
//  Copyright © 2018 Kelsey Donavin. All rights reserved.
//

#include "VectorMyJosephus.hpp"
#include "Person.hpp"


VectorMyJosephus::VectorMyJosephus()
{
    
}

VectorMyJosephus::VectorMyJosephus(int N, int M)
{
    
}

VectorMyJosephus::~VectorMyJosephus()
{
    
}

void VectorMyJosephus::init(int N, int M)
{
    
}

void VectorMyJosephus::clear()
{
    
}

//int VectorMyJosephus::currentSize()
//{
//
//}

//bool VectorMyJosephus::isEmpty()
//{
//    
//}
//
//Person VectorMyJosephus::eliminateNext()
//{
//    
//}

void VectorMyJosephus::printAll()
{
    
}
