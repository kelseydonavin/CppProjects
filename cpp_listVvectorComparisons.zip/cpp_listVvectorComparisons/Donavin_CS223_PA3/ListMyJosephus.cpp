//
//  ListMyJosephus.cpp
//  Donavin_CS223_PA3
//
//  Created by Kelsey Donavin on 9/26/18.
//  Copyright © 2018 Kelsey Donavin. All rights reserved.
//

#include "ListMyJosephus.hpp"

ListMyJosephus::ListMyJosephus()
{
    //Empty constructor, implicity invoked
}

ListMyJosephus::ListMyJosephus(int N, int M)
{
    Person person1;
    for (int i = 0; i < N; i++)
    {
        person1.setPosition(i);
        circ.push_back(person1);
    }
}

ListMyJosephus::~ListMyJosephus()
{
    clear();
}

void ListMyJosephus::init(int N, int M)
{
    Person person1;
    for (int i = 0; i < N; i++)
    {
        person1.setPosition(i);
        circ.push_back(person1);
    }
}

void ListMyJosephus::clear()
{
    circ.clear();
}

int ListMyJosephus::currentSize()
{
    auto size = 0.0;
    
    size = circ.size();
    
    return size;
}

bool ListMyJosephus::isEmpty()
{
    return circ.empty();
}

//Person ListMyJosephus::eliminateNext()
//{
//    //use remove()
//    //call isempty
//
//    Person personObj;
//
//    if (isEmpty())
//    {
//        cout << "List is empty. " << endl;
//        return personObj;
//    }
//
//    //loop through, counting till M if size() - 1 = count, count = 0; until Mcount = M, then data = person.getData(), circ.remove(person1.getdat(data));
//
//
//    for(int i = 0; i < M; i++)
//    {
//        for(auto const& j: circ)
//        {
//            if (i == M)
//            {
//                 circ.remove(j);
//            }
//            i++;
//        }
//    }

//    for (int k = 0; k < N; k++)
//    {
//        circ.remove(personObj);
//    }
    
//    return personObj;
//}

void ListMyJosephus::printAll()
{
    if (isEmpty())
    {
        cout << "List is empty. " << endl;
    }
    else
    {
        cout << "{";
        for (auto const& i: circ)
        {
            cout << i.getPosition() << " ";
        }
        cout << "}" << endl;
    }
}
