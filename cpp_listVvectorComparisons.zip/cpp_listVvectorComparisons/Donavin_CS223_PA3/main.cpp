//Programmer: Kelsey Donavin
//Class: CptS 223, Fall 2018
//WSU ID: 011474122
//Programming Assignment 3
//
//Description:
//
//Credit: Hassan Ghasemzadeh, Amir Sayyafan, Weiss Textbook

#include "ListMyJosephus.hpp"
#include "VectorMyJosephus.hpp"


//ask for N and M, then call ListMyJosephus(N, M)

int main(void)
{
    
    ListMyJosephus list;
    
    list.init(4,1);
    list.printAll();
    
}
