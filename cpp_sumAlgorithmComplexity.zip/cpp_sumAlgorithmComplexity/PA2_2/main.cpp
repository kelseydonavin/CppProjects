//
//  main.cpp
//  PA2_2
//
//  Created by Kelsey Donavin on 9/12/18.
//  Copyright © 2018 Kelsey Donavin. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
