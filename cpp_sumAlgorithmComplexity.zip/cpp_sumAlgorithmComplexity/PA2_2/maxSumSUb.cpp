#include "maxSubSUm.hpp"

int MaxSubSum::maxSubSum1(const vector<int> &data)
{
    int maxSum = 0;
    
    for(int i = 0; i < data.size(); ++i)
    {
        for (int j = i; j < data.size(); ++j)
        {
            int thisSum = 0;
            
            for (int k = i; k <= j; ++k)
            {
                thisSum += data[k];
            }
            
            if(thisSum > maxSum)
            {
                maxSum = thisSum;
            }
        }
    }
    return maxSum;
}

int MaxSubSum::maxSubSum2(const vector<int> &data)
{
    int maxSum = 0;
    
    for(int i = 0; i < data.size(); ++i)
    {
        int thisSum = 0;
        
        for(int j = i; j < data.size(); ++j)
        {
            thisSum += data[j];
            
            if(thisSum > maxSum)
            {
                maxSum = thisSum;
            }
        }
    }
    
    return maxSum;
}

int MaxSubSum::max3(int left, int right, int total)
{
    if (left > right)
    {
        if (left > total)
        {
            return left;
        }
    }
    
    else if (right > left)
    {
        if (right > total)
        {
            return right;
        }
    }
    
    else if (total > right)
    {
        if (total > left)
        {
            return total;
        }
    }
}

int MaxSubSum::maxSumRec(const vector <int> &data, int left, int right)
{
    if (left == right)
    {
        if (data[left] > 0)
        {
            return data[left];
        }
        else
        {
            return 0;
        }
    }
    
    int center = (left + right) / 2;
    int maxLeftSum = maxSumRec(data, left, center);
    int maxRightSum = maxSumRec(data, center + 1, right);
    
    int maxLeftBorderSum = 0, leftBorderSum = 0;
    
    for (int i = center; i >= left; --i)
    {
        leftBorderSum += data[i];
        
        if (leftBorderSum > maxLeftBorderSum)
        {
            maxLeftBorderSum = leftBorderSum;
        }
    }
    
    int maxRightBorderSum = 0, rightBorderSum = 0;
    
    for (int j = center + 1; j <= right; ++j)
    {
        rightBorderSum += data[j];
        
        if (rightBorderSum > maxRightBorderSum)
        {
            maxRightBorderSum = rightBorderSum;
        }
    }
    
    return max3(maxLeftSum, maxRightSum, maxLeftBorderSum + maxRightBorderSum);
}

int MaxSubSum::maxSubSum3(const vector<int> &data)
{
    return maxSumRec(data, 0, data.size() - 1);
}

int MaxSubSum::maxSubSum4(const vector<int> &data)
{
    int maxSum = 0, thisSum = 0;
    
    for (int j = 0; j < data.size(); ++j)
    {
        thisSum += data[j];
        
        if (thisSum > maxSum)
        {
            maxSum = thisSum;
        }
        else if (thisSum < 0)
        {
            thisSum = 0;
        }
    }
    
    return maxSum;
}
