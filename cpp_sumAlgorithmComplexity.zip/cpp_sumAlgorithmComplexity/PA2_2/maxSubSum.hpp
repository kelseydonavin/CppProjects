#pragma once

#include <iostream>
#include <vector>

using std::cin;
using std::cout;
using std::endl;
using std::vector;

class MaxSubSum
{
public:
    MaxSubSum()
    {
        
    }
    MaxSubSum(const MaxSubSum &copy)
    {
        
    }
    
    ~MaxSubSum()
    {
        
    }
    
    int maxSubSum1(const vector<int> &data);
    int maxSubSum2(const vector<int> &data);
    int maxSubSum3(const vector<int> &data);
    int maxSubSum4(const vector<int> &data);
    
    int max3(int left, int right, int total);
    
    int maxSumRec(const vector<int> &data, int left, int right);
};
