//Programmer: Kelsey Donavin
//Class: CptS 223, Fall 2018
//WSU ID: 011474122
//Programming Assignment 2
//
//Description: A program that will help us compare performances of four different max subsequence algorithms
//
//Credit: Hassan Ghasemzadeh, Amir Sayyafan, Weiss Textbook


#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <chrono>

#include "maxSubSum.hpp"

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::ios;
using std::ifstream;
using std::ofstream;
using std::vector;

int main(int argc, const char * argv[])
{
    MaxSubSum maxSubSum;
    
    string userInput, answer;
    
    ifstream inputFile;
    
    int testCount = 0, counter = 0;
    
    while (answer != "N")
    {
        cout << "Please enter the file name: ";
        cin >> userInput;
        
        cout << endl;
        
        cout << "How many times would you like to test this file? ";
        cin >> testCount;
        
        inputFile.open(userInput);
        
        
        vector<int> dataVector;
        
        char line[100] = "";
        
        int data = 0, i = 0;
        
        /////////////
        
        if (inputFile.is_open())
        {
            cout << "File opened successfully...\n\n";
        }
        else
        {
            cout << "Failed to open file...\n\n";
        }
        
        
        while (!inputFile.eof())
        {
            inputFile.getline(line, 10);
            
            data = atoi(line);
            
            dataVector.push_back(data);
            
            i += 1;
        }
        
        /////////
        
        while (counter < testCount)
        {
            /////////////
            int max = 0;
            
            clock_t timeToRun1 = 0;
            
            timeToRun1 = clock();
            max = maxSubSum.maxSubSum1(dataVector);
            timeToRun1 = clock() - timeToRun1;
            
            cout << "----- MaxSubSum1 -----" << endl;
            cout << "Size: " << dataVector.size() << endl;
            cout << "Max: " << max << endl;
            cout << "Runtime: " << ((float)timeToRun1) / CLOCKS_PER_SEC << " seconds" << endl << endl;
            
            ////////////
            max = 0;
            
            clock_t timeToRun2 = 0;
            
            timeToRun2 = clock();
            max = maxSubSum.maxSubSum2(dataVector);
            timeToRun2 = clock() - timeToRun2;
            
            cout << "----- MaxSubSum2 -----" << endl;
            cout << "Size: " << dataVector.size() << endl;
            cout << "Max: " << max << endl;
            cout << "Runtime: " << ((float)timeToRun2) / CLOCKS_PER_SEC << " seconds"<< endl << endl;
            
            ////////////
            max = 0;
            
            clock_t timeToRun3 = 0;
            
            timeToRun3 = clock();
            max = maxSubSum.maxSubSum3(dataVector);
            timeToRun3 = clock() - timeToRun3;
            
            cout << "----- MaxSubSum3 -----" << endl;
            cout << "Size: " << dataVector.size() << endl;
            cout << "Max: " << max << endl;
            cout << "Runtime: " << ((float)timeToRun3) / CLOCKS_PER_SEC << " seconds" << endl << endl;
            
            ////////////
            max = 0;
            
            clock_t timeToRun4 = 0;
            
            timeToRun4 = clock();
            max = maxSubSum.maxSubSum4(dataVector);
            timeToRun4 = clock() - timeToRun4;
            
            cout << "----- MaxSubSum4 -----" << endl;
            cout << "Size: " << dataVector.size() << endl;
            cout << "Max: " << max << endl;
            cout << "Runtime: " << ((float)timeToRun4) / CLOCKS_PER_SEC << " seconds" << endl << endl;
            
            ////////////
            
            counter += 1;
        }
        
        if ( counter == testCount)
        {
            cout << "Would you like to test another file? Enter 'Y' or 'N': ";
            cin >> answer;
            cout << endl << endl;
            if (answer == "Y")
            {
                counter = 0;
            }
        }
        
        inputFile.close();
        
    }
    return 0;
}
